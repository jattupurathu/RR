package com.jay.rr.core;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.jay.rr.commons.IConstants;
import com.jay.rr.model.MerchantDetailsPojo;
import com.jay.rr.service.FindNearestMerchantService;

@RestController
@RequestMapping(IConstants.NEAREST_MERCHANT)

public class CoreController {
	
	@Autowired
	FindNearestMerchantService findNearestMerchantService;
	@RequestMapping(method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_VALUE})
    public ArrayList<MerchantDetailsPojo> find(@PathVariable double longi, @PathVariable double lati, @PathVariable int range,
    		@PathVariable int hasShower /* product 1*/ ,
    		@PathVariable int hasLocker /* product 2*/,
    		@PathVariable int isWestern /* product 3*/) {
		System.out.println(longi);
		System.out.println(lati);
		System.out.println(range);
		return findNearestMerchantService.find(longi, lati, range,hasShower>0?true:false,hasLocker>0?true:false,isWestern>0?true:false);
	}
	
}

package com.jay.rr.commons;

public interface IConstants {
	
	public static String NEAREST_MERCHANT = "/findMerchant/{longi}/{lati}/{range}/{hasShower}/{hasLocker}/{isWestern}";
	public static String PROFILE_REG_FIRST_TIME = "/profileFirsTime/{mobile}";
	public static String PROFILE_OTP_VERIFY = "/profileVerify/{mobile}/{otp}";
	public static String PROFILE_OTP_RESEND = "/profileResendOTP/{mobile}";
	public static String PROFILE_REGISTER = "/profile/register";
	public static String SITE_REGISTER="/site/register";
}

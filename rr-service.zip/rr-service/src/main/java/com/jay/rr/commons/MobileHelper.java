package com.jay.rr.commons;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jay.rr.model.MerchantOTPModel;


public class MobileHelper {
	private final static RestTemplate restTemplate = new RestTemplate();
	private final static List<MediaType> acceptableMediaTypes = new ArrayList<MediaType>();
	private final static HttpHeaders headers = new HttpHeaders();
	private static HttpEntity<?> entity = null;

	static {
        acceptableMediaTypes.add(MediaType.APPLICATION_JSON);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptableMediaTypes);
        entity =  new HttpEntity<Object>(headers);
	}

	public static MerchantOTPModel connect(String mainUrl) {
		MerchantOTPModel model = null;
		System.out.println("mainUrl: "+mainUrl);	
		try {
			URL url = new URL(mainUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			System.out.println("conn.getResponseCode(): "+conn.getResponseCode());
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			StringBuilder response = new StringBuilder();
			while ((output = br.readLine()) != null) {
				response.append(output);
			}
			ObjectMapper mapper = new ObjectMapper();
			model = mapper.readValue(response.toString(), MerchantOTPModel.class);
			System.out.println(model.toString());
			conn.disconnect();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return model;
	}
		
	public static MerchantOTPModel verifyOTP(String mobiles, String authkey, String url, String otp) {
		if( validateMobile(mobiles)) {
			//Prepare parameter string 
			StringBuilder sbPostData= new StringBuilder(url);
			sbPostData.append("authkey="+authkey); 
			sbPostData.append("&mobile="+mobiles);
			sbPostData.append("&otp="+otp);
			return connect(sbPostData.toString());
		}else {
			MerchantOTPModel model=new MerchantOTPModel();
			model.setMessage(mobiles+" is invalid");
			model.setType("error");
			return model;
		}
	}
	public static MerchantOTPModel sendOTP(String mobiles,String authkey, String mainUrl, String sender, String otpExpiry, String otplength) {
		// check if the mobile number is valid
		if( validateMobile(mobiles)) {
			//Prepare parameter string 
			StringBuilder sbPostData= new StringBuilder(mainUrl);
			sbPostData.append("authkey="+authkey); 
			sbPostData.append("&mobiles="+mobiles);
			sbPostData.append("&sender="+sender);
			sbPostData.append("&otp_expiry="+otpExpiry);
			sbPostData.append("&otp_length="+otplength);
			return connect(sbPostData.toString());
		}else {
			MerchantOTPModel model=new MerchantOTPModel();
			model.setMessage(mobiles+" is invalid");
			model.setType("error");
			return model;
		}
	}
	
	public static MerchantOTPModel reSendOTP(String mobile,String authkey, String mainUrl) {
		// check if the mobile number is valid
		if( validateMobile(mobile)) {
			//Prepare parameter string 
			StringBuilder sbPostData= new StringBuilder(mainUrl);
			sbPostData.append("authkey="+authkey); 
			sbPostData.append("&mobile="+mobile);
			sbPostData.append("&retrytype=voice");
			return connect(sbPostData.toString());
		}else {
			MerchantOTPModel model=new MerchantOTPModel();
			model.setMessage(mobile+" is invalid");
			model.setType("error");
			return model;
		}
	}

	
	public static boolean validateMobile(String mobile){
		
		mobile.trim();
		mobile = mobile.replaceAll("\\s", "");
		while (mobile.startsWith("+")) {
			mobile = new String(mobile.toString().substring(1));
		}
		
		if (mobile.matches("^\\s*\\d+\\s*$")) {

			System.out.println("match");
			if (mobile.length() == 10 || mobile.length() == 12) {
				if ((mobile != null)) {
					if (mobile.matches("9{1}1{1}[7-8-9]{1}[0-9]{9}")) {
						System.out.println(" correct number");

					} else if (mobile.matches("[7-8-9]{1}[0-9]{9}")) {} 
					else {
						return false;
					}
				} else {
					return false;
				}

			} else {
				return false;
			}
		} else {
			return false;
		}
		return true;
	}

}

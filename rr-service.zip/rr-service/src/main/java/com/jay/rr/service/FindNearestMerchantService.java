package com.jay.rr.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jay.rr.model.Site;
import com.jay.rr.model.MerchantDetailsPojo;
import com.jay.rr.repo.SiteRepo;
import com.jay.rr.utils.Haversine;

@Service
public class FindNearestMerchantService {

	public ArrayList<MerchantDetailsPojo> merchantList = null;
	@Autowired
	SiteRepo siteRepo;

	//private final DistanceHelper distanceHelper = new DistanceHelper();
	
	public ArrayList<MerchantDetailsPojo> find (double longi, double lati, int range, boolean hasShower, boolean hasLocker, boolean isWestern){
		//get all the merchants of same range from db
		//TODO: Use the db and remove the db
		System.out.println("longitude: "+ longi);
		System.out.println("latitude: "+ lati);
		System.out.println("Range: "+ range+" Kms");
		System.out.println("Product 1: "+ hasShower);
		System.out.println("Product 2: "+ hasLocker);
		System.out.println("Product 3: "+ isWestern);
		//ArrayList<Merchant> list = DummyMerchantdetails.getMDetailsPojo();
		Iterable<Site> itn = siteRepo.findAll();
		merchantList = new ArrayList<MerchantDetailsPojo>();
		//find the populate MerchantdetailsPojo
		// find the distance of each merchant from current location
		for(Site site: itn) {
			// check if the product criteria meets
			System.out.println("merchant: "+site.toString());
			if(site.isHasLocker() == hasLocker && site.isHasShower() == hasShower && site.isWestern() == isWestern) {
				//System.out.println(merchant.toString());
				MerchantDetailsPojo pojo = new MerchantDetailsPojo();
				//product1 = has shower
				pojo.setProduct1(site.isHasShower());
				//product 2 = has locker
				pojo.setProduct2(site.isHasLocker());
				// product 3 = is western
				pojo.setProduct3(site.isWestern());
				pojo.setLati(site.getLati());
				pojo.setLongi(site.getLongi());
				//currently set for KM's
				double distance = Haversine.distance(longi,lati,site.getLongi(), site.getLati());
				System.out.println("distance: "+distance);
				if(distance>=0 && distance <= range) {
					pojo.setPreferred(true);
				}
				pojo.setDistance(distance);
				pojo.setProfileID(site.getProfID());
				merchantList.add(pojo);
			}
		}
		System.out.println("Total Merchants: "+ merchantList.size());
		return merchantList;
	}
	
	
}

package com.jay.rr.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SITE_DTL")
public class Site {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private long id;
	@Column(name = "profID")
	private long profID;
	@Column(name = "name")
	private String name = null;
	@Column(name = "longi")
	private double longi = 0;
	@Column(name = "lati")
	private double lati = 0;
	
	/*
	 *    hasShower    BOOLEAN default false,
   hasLocker    BOOLEAN default false,
   isAsian      BOOLEAN default false,
   isWestern    BOOLEAN default false,
	 * */
	
	private boolean hasShower = false;
	private boolean hasLocker = false;
	private boolean isAsian = false;
	private boolean isWestern = false;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getLongi() {
		return longi;
	}
	public void setLongi(double longi) {
		this.longi = longi;
	}
	public double getLati() {
		return lati;
	}
	public void setLati(double lati) {
		this.lati = lati;
	}
	public boolean isHasShower() {
		return hasShower;
	}
	public void setHasShower(boolean hasShower) {
		this.hasShower = hasShower;
	}
	public boolean isHasLocker() {
		return hasLocker;
	}
	public void setHasLocker(boolean hasLocker) {
		this.hasLocker = hasLocker;
	}
	public boolean isAsian() {
		return isAsian;
	}
	public void setAsian(boolean isAsian) {
		this.isAsian = isAsian;
	}
	public boolean isWestern() {
		return isWestern;
	}
	public void setWestern(boolean isWestern) {
		this.isWestern = isWestern;
	}

	public long getProfID() {
		return profID;
	}
	public void setProfID(long profID) {
		this.profID = profID;
	}
	@Override
	public String toString() {
		return "Site [id=" + id + ", profID=" + profID + ", name=" + name + ", longi=" + longi + ", lati=" + lati
				+ ", hasShower=" + hasShower + ", hasLocker=" + hasLocker + ", isAsian=" + isAsian + ", isWestern="
				+ isWestern + "]";
	}
}

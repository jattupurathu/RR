package com.jay.rr.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.jay.rr.model.Profile;

@Repository
public interface ProfileRepo extends CrudRepository<Profile, Long> {
	Profile findById(long ID);
//	List<Merchant> findAll();
//	void add(Merchant merchant);
//	void addAll(List<Merchant> list);
}

package com.jay.rr.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PROFILE_DTL")
public class Profile {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private long id;
	@Column(name = "firstname")
	private String firstName = null;
	@Column(name = "lastName")
	private String lastName = null;
	@Column(name = "email")
	private String email = null;
	@Column(name = "password")
	private String password = null;
	@Column(name = "add1")
	private String add1 = null;
	@Column(name = "add2")
	private String add2 = null;
	@Column(name = "add3")
	private String add3 = null;
	@Column(name = "city")
	private String city = null;
	@Column(name = "state")
	private String state = null;
	@Column(name = "pincode")
	private String pincode = null;
	@Column(name = "mobile")
	private String mobile = null;
//	@Column(name = "longi")
//	private double longi = 0;
//	@Column(name = "lati")
//	private double lati = 0;
	
	/*
	 *    hasShower    BOOLEAN default false,
   hasLocker    BOOLEAN default false,
   isAsian      BOOLEAN default false,
   isWestern    BOOLEAN default false,
	 * */
	
//	private boolean hasShower = false;
//	private boolean hasLocker = false;
//	private boolean isAsian = false;
//	private boolean isWestern = false;
	private boolean isMerchant = false;

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAdd1() {
		return add1;
	}
	public void setAdd1(String add1) {
		this.add1 = add1;
	}
	public String getAdd2() {
		return add2;
	}
	public void setAdd2(String add2) {
		this.add2 = add2;
	}
	public String getAdd3() {
		return add3;
	}
	public void setAdd3(String add3) {
		this.add3 = add3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
//	public double getLongi() {
//		return longi;
//	}
//	public void setLongi(double longi) {
//		this.longi = longi;
//	}
//	public double getLati() {
//		return lati;
//	}
//	public void setLati(double lati) {
//		this.lati = lati;
//	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
//	public boolean isHasShower() {
//		return hasShower;
//	}
//	public void setHasShower(boolean hasShower) {
//		this.hasShower = hasShower;
//	}
//	public boolean isHasLocker() {
//		return hasLocker;
//	}
//	public void setHasLocker(boolean hasLocker) {
//		this.hasLocker = hasLocker;
//	}
//	public boolean isAsian() {
//		return isAsian;
//	}
//	public void setAsian(boolean isAsian) {
//		this.isAsian = isAsian;
//	}
//	public boolean isWestern() {
//		return isWestern;
//	}
//	public void setWestern(boolean isWestern) {
//		this.isWestern = isWestern;
//	}
	public boolean isMerchant() {
		return isMerchant;
	}
	public void setMerchant(boolean isMerchant) {
		this.isMerchant = isMerchant;
	}
	
	@Override
	public String toString() {
		return "Profile [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", password=" + password + ", add1=" + add1 + ", add2=" + add2 + ", add3=" + add3 + ", city=" + city
				+ ", state=" + state + ", pincode=" + pincode + ", mobile=" + mobile + ", isMerchant=" + isMerchant
				+ "]";
	}

	
	
}

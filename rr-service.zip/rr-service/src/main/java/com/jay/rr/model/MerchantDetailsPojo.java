package com.jay.rr.model;

public class MerchantDetailsPojo {
	
	private Long profileID;
	private double longi = 0;
	private double lati = 0;
	private double distance = 0;
	private boolean preferred = false;
	private boolean product1 = false;
	private boolean product2 = false;
	private boolean product3 = false;
	
	public boolean isProduct1() {
		return product1;
	}
	public void setProduct1(boolean product1) {
		this.product1 = product1;
	}
	public boolean isProduct2() {
		return product2;
	}
	public void setProduct2(boolean product2) {
		this.product2 = product2;
	}
	public boolean isProduct3() {
		return product3;
	}
	public void setProduct3(boolean product3) {
		this.product3 = product3;
	}
	public boolean isPreferred() {
		return preferred;
	}
	public void setPreferred(boolean peferred) {
		this.preferred = peferred;
	}
	public double getLongi() {
		return longi;
	}
	public void setLongi(double longi) {
		this.longi = longi;
	}
	public double getLati() {
		return lati;
	}
	public void setLati(double lati) {
		this.lati = lati;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public Long getProfileID() {
		return profileID;
	}
	public void setProfileID(Long profileID) {
		this.profileID = profileID;
	}
}

package com.jay.rr.main;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
//import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@ComponentScan(basePackages={"com.jay.rr.user","com.jay.rr.merchant","com.jay.rr.core","com.jay.rr.service","com.jay.rr.utils"})
@EntityScan(basePackages = {"com.jay.rr.model"})
@EnableJpaRepositories(basePackages = {"com.jay.rr.repo"})
@EnableTransactionManagement
//@EnableMongoRepositories ("com.jay.rr")
public class RRServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RRServiceApplication.class, args);
    }

//    @Bean
//    public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
//        return args -> {
//
//            System.out.println("Let's inspect the beans provided by Spring Boot:");
//
//            String[] beanNames = ctx.getBeanDefinitionNames();
//            Arrays.sort(beanNames);
//            for (String beanName : beanNames) {
//                System.out.println(beanName);
//            }
//
//        };
//    }

}

package com.jay.rr.repo;

import org.springframework.data.repository.CrudRepository;

import com.jay.rr.model.Site;

public interface SiteRepo extends CrudRepository<Site, Long> {

}

package com.jay.rr.registration;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.jay.rr.commons.IConstants;
import com.jay.rr.commons.MobileHelper;
import com.jay.rr.model.Profile;
import com.jay.rr.model.Site;
import com.jay.rr.model.MerchantOTPModel;
import com.jay.rr.service.RegisterService;

@RestController
public class RegistrationController {
	
	@Autowired
	private Environment env;
	@Autowired
	private RegisterService registerService;

	@RequestMapping(value=IConstants.PROFILE_REG_FIRST_TIME,method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_VALUE})
	// return otp id 
	public MerchantOTPModel firstTimeMerchant(@PathVariable String mobile) {
		String authkey = env.getProperty("authMobileKey");
		String sendUrl = env.getProperty("sendUrl");
		String sender = env.getProperty("sender");
		String otpExpiry = env.getProperty("otpExpiry");
		String otpLength = env.getProperty("otpLength");
		System.out.println("authkey: "+authkey);
		System.out.println("mobile: "+mobile);
		return MobileHelper.sendOTP(mobile, authkey,sendUrl,sender,otpExpiry,otpLength);
	}
	
	@RequestMapping(value=IConstants.PROFILE_OTP_VERIFY,method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_VALUE})
	// return otp id 
	public MerchantOTPModel verifyOTPMerchant(@PathVariable String mobile,@PathVariable String otp) {
		String verifyUrl = env.getProperty("verifyUrl");
		String authkey = env.getProperty("authMobileKey");
		return MobileHelper.verifyOTP(mobile, authkey, verifyUrl, otp);
	}
	
	@RequestMapping(value=IConstants.PROFILE_OTP_RESEND,method = RequestMethod.GET,produces = {MediaType.APPLICATION_JSON_VALUE})
	// return otp id 
	public MerchantOTPModel resendOTP(@PathVariable String mobile) {
		String authkey = env.getProperty("authMobileKey");
		String resendUrl = env.getProperty("resendUrl");
		System.out.println("authkey: "+authkey);
		System.out.println("mobile: "+mobile);
		return MobileHelper.reSendOTP(mobile, authkey,resendUrl);
	}
	
	/*
	 * 
	 * {
    "id": 0,
    "firstName": "firstName",
    "lastName": "lastName",
    "email": "unnishankar@gmail.com",
    "password": "xxxxxxx",
    "add1": "vallabh Nagar",
    "add2": "pimpri",
    "add3": "add3",
    "city": "Pune",
    "state": "Maharashtra",
    "pincode": "411018",
    "mobile": "918600000000",
    "longi": 0,
    "lati": 0,
}
	 */
	@RequestMapping(value=IConstants.PROFILE_REGISTER,method = RequestMethod.POST,produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Profile> registerMerchant(@RequestBody Profile profile) {
		return registerService.registerMerchant(profile);
	}
	
	@RequestMapping(value=IConstants.SITE_REGISTER,method = RequestMethod.POST,produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Site> registerSite(@RequestBody Site site){
		return registerService.registerSite(site);
	}
	
	
}

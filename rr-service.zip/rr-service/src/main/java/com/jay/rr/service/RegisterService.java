package com.jay.rr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jay.rr.model.Profile;
import com.jay.rr.model.Site;
import com.jay.rr.repo.ProfileRepo;
import com.jay.rr.repo.SiteRepo;

@Service
public class RegisterService {
	
	@Autowired
	ProfileRepo profileRepo;
	@Autowired
	SiteRepo siteRepo;
	
	public ResponseEntity<Profile> registerMerchant(Profile profile) {
		profileRepo.save(profile);
		return ResponseEntity.ok().body(profile);
	}

	public ResponseEntity<Site> registerSite(Site site) {
		siteRepo.save(site);
		return ResponseEntity.ok().body(site);
	}
}
